package seatone;

public interface Mover {
	void move();
}
