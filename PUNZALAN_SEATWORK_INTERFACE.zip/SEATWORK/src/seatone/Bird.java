package seatone;

public class Bird extends Animal implements SoundMaker, Mover {

	public void makeSound() {
		System.out.println("Tweet!");
	}
	
	public void move() {
		System.out.println("The bird flies.");
	}
	
	public void describe() {
		System.out.println("I'm a colorful bird named " + getName());
	}

}
