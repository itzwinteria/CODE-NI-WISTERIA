package seatone;

public class Main {
	

	public static void main(String[] args) {
		Dog dog = new Dog();
		Bird bird = new Bird();
		
		dog.setName("Buddy");
		bird.setName("Kiwi");
		
		dog.describe();
		dog.makeSound();
		dog.move();
		System.out.println();
		
		bird.describe();
		bird.makeSound();
		bird.move();

	}

}
