package seatone;

public interface SoundMaker {
	void makeSound();
}
