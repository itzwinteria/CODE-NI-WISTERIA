package seatone;

public class Dog extends Animal implements SoundMaker, Mover {

	public void makeSound() {
		System.out.println("Woof");
	}
	
	public void move() {
		System.out.println("The dog runs.");
	}
	
	public void describe() {
		System.out.println("I'm a loyal dog named " + getName());
	}

}
