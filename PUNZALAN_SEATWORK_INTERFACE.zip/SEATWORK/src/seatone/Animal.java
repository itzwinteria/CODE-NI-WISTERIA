package seatone;

public abstract class Animal {
	private String name;
	public abstract void describe();
	
	public String getName() {
		return name;
	}
	
	public void setName(String animalName) {
		this.name = animalName;
	}
	
	

}
